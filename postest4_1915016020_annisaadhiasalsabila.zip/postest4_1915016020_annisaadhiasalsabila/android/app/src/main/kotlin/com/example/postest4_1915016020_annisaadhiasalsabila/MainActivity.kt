package com.example.postest4_1915016020_annisaadhiasalsabila

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
